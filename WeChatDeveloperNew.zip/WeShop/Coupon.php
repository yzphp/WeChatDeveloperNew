<?php
/**
 * Created by PhpStorm.
 * User: iwang
 * Date: 2021/9/9
 * Time: 22:35
 */
namespace WeShop;
class Coupon
{

}